extends CanvasLayer



#When quit button is pressed it will end game
func _on_quit_pressed() -> void:
	get_tree().quit()


#func _on_play_again_pressed() -> void:
	#get_tree().change_scene_to_file("res://main.tscn")
	#Global.gold = 0
	
func _on_leader_board_pressed() -> void:
	SilentWolf.Scores.save_score(GameState.player_name, GameState.score)
	get_tree().change_scene_to_file("res://addons/silent_wolf/Scores/Leaderboard.tscn")
